# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class InvokeEndpointProxyResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'error': 'ErrorInfo',
        'result': 'object',
        'status': 'str'
    }

    attribute_map = {
        'error': 'error',
        'result': 'result',
        'status': 'status'
    }

    def __init__(self, error=None, result=None, status=None):
        r"""InvokeEndpointProxyResponse

        The model defined in huaweicloud sdk

        :param error: 
        :type error: :class:`huaweicloudsdkcodeartspipeline.v2.ErrorInfo`
        :param result: **参数解释**： 错误结果。 **取值范围**： 不涉及。 
        :type result: object
        :param status: **参数解释**： 状态值。 **取值范围**： 不涉及。 
        :type status: str
        """
        
        super().__init__()

        self._error = None
        self._result = None
        self._status = None
        self.discriminator = None

        if error is not None:
            self.error = error
        if result is not None:
            self.result = result
        if status is not None:
            self.status = status

    @property
    def error(self):
        r"""Gets the error of this InvokeEndpointProxyResponse.

        :return: The error of this InvokeEndpointProxyResponse.
        :rtype: :class:`huaweicloudsdkcodeartspipeline.v2.ErrorInfo`
        """
        return self._error

    @error.setter
    def error(self, error):
        r"""Sets the error of this InvokeEndpointProxyResponse.

        :param error: The error of this InvokeEndpointProxyResponse.
        :type error: :class:`huaweicloudsdkcodeartspipeline.v2.ErrorInfo`
        """
        self._error = error

    @property
    def result(self):
        r"""Gets the result of this InvokeEndpointProxyResponse.

        **参数解释**： 错误结果。 **取值范围**： 不涉及。 

        :return: The result of this InvokeEndpointProxyResponse.
        :rtype: object
        """
        return self._result

    @result.setter
    def result(self, result):
        r"""Sets the result of this InvokeEndpointProxyResponse.

        **参数解释**： 错误结果。 **取值范围**： 不涉及。 

        :param result: The result of this InvokeEndpointProxyResponse.
        :type result: object
        """
        self._result = result

    @property
    def status(self):
        r"""Gets the status of this InvokeEndpointProxyResponse.

        **参数解释**： 状态值。 **取值范围**： 不涉及。 

        :return: The status of this InvokeEndpointProxyResponse.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this InvokeEndpointProxyResponse.

        **参数解释**： 状态值。 **取值范围**： 不涉及。 

        :param status: The status of this InvokeEndpointProxyResponse.
        :type status: str
        """
        self._status = status

    def to_dict(self):
        import warnings
        warnings.warn("InvokeEndpointProxyResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, InvokeEndpointProxyResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
