# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class RunPipelineResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'pipeline_run_id': 'str',
        'error_msg': 'str'
    }

    attribute_map = {
        'pipeline_run_id': 'pipeline_run_id',
        'error_msg': 'error_msg'
    }

    def __init__(self, pipeline_run_id=None, error_msg=None):
        r"""RunPipelineResponse

        The model defined in huaweicloud sdk

        :param pipeline_run_id: **参数解释**： 流水线运行实例ID，[启动流水线](RunPipeline.xml)接口的返回值即为流水线运行实例ID。 **取值范围**： 32位字符，仅由数字和字母组成。 
        :type pipeline_run_id: str
        :param error_msg: **参数解释**： 流水线运行失败详情。 **取值范围**： 不涉及。 
        :type error_msg: str
        """
        
        super().__init__()

        self._pipeline_run_id = None
        self._error_msg = None
        self.discriminator = None

        if pipeline_run_id is not None:
            self.pipeline_run_id = pipeline_run_id
        if error_msg is not None:
            self.error_msg = error_msg

    @property
    def pipeline_run_id(self):
        r"""Gets the pipeline_run_id of this RunPipelineResponse.

        **参数解释**： 流水线运行实例ID，[启动流水线](RunPipeline.xml)接口的返回值即为流水线运行实例ID。 **取值范围**： 32位字符，仅由数字和字母组成。 

        :return: The pipeline_run_id of this RunPipelineResponse.
        :rtype: str
        """
        return self._pipeline_run_id

    @pipeline_run_id.setter
    def pipeline_run_id(self, pipeline_run_id):
        r"""Sets the pipeline_run_id of this RunPipelineResponse.

        **参数解释**： 流水线运行实例ID，[启动流水线](RunPipeline.xml)接口的返回值即为流水线运行实例ID。 **取值范围**： 32位字符，仅由数字和字母组成。 

        :param pipeline_run_id: The pipeline_run_id of this RunPipelineResponse.
        :type pipeline_run_id: str
        """
        self._pipeline_run_id = pipeline_run_id

    @property
    def error_msg(self):
        r"""Gets the error_msg of this RunPipelineResponse.

        **参数解释**： 流水线运行失败详情。 **取值范围**： 不涉及。 

        :return: The error_msg of this RunPipelineResponse.
        :rtype: str
        """
        return self._error_msg

    @error_msg.setter
    def error_msg(self, error_msg):
        r"""Sets the error_msg of this RunPipelineResponse.

        **参数解释**： 流水线运行失败详情。 **取值范围**： 不涉及。 

        :param error_msg: The error_msg of this RunPipelineResponse.
        :type error_msg: str
        """
        self._error_msg = error_msg

    def to_dict(self):
        import warnings
        warnings.warn("RunPipelineResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RunPipelineResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
